
const loginForm = document.getElementById("loginForm");
const usuarioInput = document.getElementById("usuario");
const senhaInput = document.getElementById("senha");
const togglePassword = document.getElementById("togglePassword");
const message = document.getElementById("message");

// Usuários de teste
const usuarios = [
    {
        usuario: "aluno01",
        senha: "1234",
        perfil: "aluno"
    },
    {
        usuario: "prof01",
        senha: "1234",
        perfil: "professor"
    }
];

// Mostrar ou ocultar senha
togglePassword.addEventListener("click", function () {
    if (senhaInput.type === "password") {
        senhaInput.type = "text";
        togglePassword.textContent = "🙈";
    } else {
        senhaInput.type = "password";
        togglePassword.textContent = "👁";
    }
});

// Realizar login
loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const usuarioDigitado = usuarioInput.value.trim();
    const senhaDigitada = senhaInput.value.trim();

    const usuarioEncontrado = usuarios.find(function (usuario) {
        return usuario.usuario === usuarioDigitado &&
               usuario.senha === senhaDigitada;
    });

    if (!usuarioEncontrado) {
        message.textContent = "Usuário ou senha incorretos.";
        message.style.color = "red";
        return;
    }

    // Guardar o perfil para a próxima tela
    sessionStorage.setItem("perfil", usuarioEncontrado.perfil);
    sessionStorage.setItem("usuario", usuarioEncontrado.usuario);

    message.style.color = "green";
    message.textContent = "Login realizado!";

    setTimeout(function () {
        window.location.href = "home.html";
    }, 500);
});
