
const perfil = sessionStorage.getItem("perfil");
const usuario = sessionStorage.getItem("usuario");

const adminLink = document.getElementById("adminLink");
const userName = document.getElementById("userName");
const logoutButton = document.getElementById("logoutButton");

// Verifica se existe login
if (!perfil || !usuario) {
    window.location.href = "index.html";
}

// Identificação do usuário
userName.textContent = perfil === "professor"
    ? "Professor"
    : "Aluno";

// Mostrar administração somente ao professor
if (perfil === "professor") {
    adminLink.style.display = "inline-block";
}

// Sair da plataforma
logoutButton.addEventListener("click", function () {
    sessionStorage.clear();
    window.location.href = "index.html";
});
